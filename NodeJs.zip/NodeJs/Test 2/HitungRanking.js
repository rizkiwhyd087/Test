const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Masukkan jumlah pemain: ", nStr => {
  const n = parseInt(nStr);
  rl.question("Masukkan skor pemain: ", scoresStr => {
    const scores = scoresStr.split(" ").map(score => parseInt(score));
    rl.question("Masukkan jumlah pertandingan GITS: ", mStr => {
      const m = parseInt(mStr);
      rl.question("Masukkan skor GITS: ", aliceStr => {
        const alice = aliceStr.split(" ").map(score => parseInt(score));
        const uniqueScores = Array.from(new Set(scores));
        const ranking = uniqueScores
          .sort((a, b) => b - a)
          .reduce((r, score, index) => {
            r[score] = index + 1;
            return r;
          }, {});

        alice.forEach(score => {
          let rank = 1;
          for (let i = 0; i < uniqueScores.length; i++) {
            if (score >= uniqueScores[i]) {
              break;
            }
            rank++;
          }
          console.log(n - rank + 1);
        });
        rl.close();
      });
    });
  });
});