const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Masukkan angka: ", nStr => {
  const n = parseInt(nStr);
  let result = "1";
  let prev = 1;
  for (let i = 2; i <= n; i++) {
    prev = prev + i - 1;
    result += `-${prev}`;
  }
  console.log(result);
  rl.close();
});
